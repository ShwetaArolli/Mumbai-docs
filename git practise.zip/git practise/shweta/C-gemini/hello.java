class hello
{

System.out.println("welcome to capgemini");

}
