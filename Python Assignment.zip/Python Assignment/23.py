allLines = []
print('Insert the text:')
while True:
    line = raw_input('')
    if line == '':
        break
    allLines.append(line)
	
fullInput = '\n'.join(allLines)
print('After Capitalizing')
print(fullInput.upper())