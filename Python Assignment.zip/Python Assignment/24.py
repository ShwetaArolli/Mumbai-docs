def even_values_string(str):  
  result = ""   
  for i in range(len(str)):  
    if i % 2 == 1:  
      result = result + str[i]
    	  
  return result  
  
  
test_string = input("Enter a string to test for character uniqeness : ")
print(even_values_string(test_string))


