The folder contains some of the PDFs that were provided by LnD during Git Virtual Training Session. 
I hope that it helps.

-Karan