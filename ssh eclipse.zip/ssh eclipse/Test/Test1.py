'''
Created on Mar 17, 2017

@author: shwhegde
'''
print("hello world")
message=raw_input("enter name:")
print(message)
