'''
Created on May 22, 2017
2)Please write a program which accepts a string from console and print the characters that have even indexes.
@author: shwhegde
'''
class second:     #class declared with class name second
    print("enter string:")
    message=list(raw_input()) #message takes items from console in the form of list
    count=len(message)        #count contains length of list message
    print count
    
    def fun(self):            #fun is function to print characters that have even index
        for i in range(0,second.count): 
            if i%2==0:         #finds even index in list message       
                print second.message[i]+",", #prints even index elements seperated by comma 

s1=second()    #creating s1 object of class second
print(s1.fun()) #calling the fun function declared