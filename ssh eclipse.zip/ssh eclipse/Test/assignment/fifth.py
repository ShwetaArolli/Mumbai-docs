'''
Created on May 23, 2017
5)A website requires the users to input username and password to register. Write a program to check the validity of password input by users.Following are the criteria for checking the password:

@author: shwhegde
'''
import re #The re module was added in Python 1.5, and provides Perl-style regular expression patterns.
class Fifth:  #class Fifth defined
    print "enter your password:"
    password=raw_input()    #takes password from console
    array=password.split(',') #split method used to seperate multiple input by comma
    def validate(self):       #validate function used to check validity of password
        length=len(Fifth.array)
        for i in range(0,length):
            psw=Fifth.array[i]
            if(len(Fifth.array[i])>=6 and len(Fifth.array[i])<=12 and (re.match ('^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[_$_#_@]).+$',psw))): #regular expression used to check  minimum of one uppercase,lowercase,number,and symbols present in password
                print "sucessful", Fifth.array[i],   #if valid password is printed
f1=Fifth() #object of class Fifth called
print(f1.validate()) #f1 object calls validate function
            
            
    