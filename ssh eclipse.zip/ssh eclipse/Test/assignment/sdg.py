'''
Created on May 22, 2017
4) Count the number of items in a list with the result in a dictionary
@author: shwhegde
'''
from collections import Counter   #A Counter is a dict subclass for counting hashable objects
class Fourth:                     #Fouth is class defined
    print "enter the elements to list:"
    mess=list(raw_input())        #mess is list which takes items from console
    print mess
    print "length of list is ",len(mess) #length of list mess is printed
    dict=dict( [ ( i,mess.count(i) ) for i in set(mess) ] ) #count of number of items in list is stored in dict
    print(dict)                          #dict is dictionary keeps count of items in list 






''