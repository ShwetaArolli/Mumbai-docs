'''
Created on May 22, 2017
1)Write a program that accepts sequence of lines as input and prints the lines after making all characters in the sentence capitalized.
@author: shwhegde
'''

message=""
var1=input("enter line limit:")
for i in range (0,var1):
    message=raw_input()
print(message.upper())



    