'''
Created on May 22, 2017

@author: shwhegde
1)Write a program that accepts sequence of lines as input and prints the lines after making all characters in the sentence capitalized.
'''
temp=""
print "enter the input: " 
message=""
while(temp.lower()!="exit"):  #takes sequence of lines until input is exit
    message += temp+"\n"      #sequence of lines stored in message
    temp=raw_input()          #enter sequence of lines to temp

print("message after capitalizing input:")
print(message.upper())        #upper() method capitalize the sequence of input
