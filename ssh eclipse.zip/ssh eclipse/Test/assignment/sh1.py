'''
Created on May 22, 2017
3)Write a function invertdict to interchange keys and values in a dictionary. For simplicity, assume that all values are unique
@author: shwhegde
'''

class Third:
    dict={'one':'1','two':'2','three':'3'}  #dict is dictionary containing key and value
    print "enter the values for dictionary:"
    def invertdict(self):                   #function invertdict to interchange key and values of dict
        res = dict((v,k) for k,v in Third.dict.iteritems())   #keys and values in dict is interchanged and stored in res
        print res                                             #interchanged key and values of dict is printed in res
        
       
t1=Third()    #object of Third is created
print(t1.invertdict()) #function invertdict is called by t1 object of class Third

