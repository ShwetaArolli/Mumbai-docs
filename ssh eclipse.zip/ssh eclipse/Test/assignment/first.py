'''
Created on May 22, 2017
)Please write a program which accepts a string from console and print the characters that have even indexes.
@author: shwhegde
'''
count=0
while(count<10):
    print "value of count",count
    count=count+1
    
print("good")    
    
        
        