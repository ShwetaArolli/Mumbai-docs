'''
Created on May 11, 2017

@author: shwhegde
'''
print "hi"
he=raw_input("enter val")
print he