'''
Created on May 22, 2017

@author: shwhegde
'''
'''
Dictionary example
Created on May 11, 2017

@author: shwhegde
'''
d={1:'one',2:'two',3:'three'}
def search(d,v):
    for i in d:
        if d[i]==v:
            return(i)
    return('the value not found')
v1=raw_input('enter a value to be recorded')
print(search(d,v1))