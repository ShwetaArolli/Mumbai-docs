import java.util.Scanner;

public class cap {
	
	public static void main(String[] agrs)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("welcome to capgemini");
		String name=sc.next();
		int empid=sc.nextInt();
		System.out.println("employee name:"+name);
		System.out.println("employee id:"+empid);
		System.out.println("thank you for entering details");
		sc.close();
		
	}

}
