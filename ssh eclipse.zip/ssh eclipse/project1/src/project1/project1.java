package project1;

public class project1 {

	public static void main(String[] args) {
	System.out.println("hello");

	}

}
