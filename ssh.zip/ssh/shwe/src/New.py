'''
Created on Mar 23, 2017

@author: shwhegde
'''

a="C:\Python27\abc.txt"
b="r"
f=open(a,b)
print(f.read())
f.close()
print"end"