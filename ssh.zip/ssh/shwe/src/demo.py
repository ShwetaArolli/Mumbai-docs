'''
Created on Mar 21, 2017

@author: shwhegde
'''

accessMode�=�"w" 
myFile�=�open(fi,�accessMode) 
myFile.write("Hi�there!")
myFile.write("How are you?")
myFile.close()

