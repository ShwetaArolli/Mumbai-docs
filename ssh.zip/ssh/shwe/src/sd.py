'''
Created on Mar 20, 2017

@author: shwhegde
'''

a="ram.txt"
b="w"
f=open(a,b)
f.writeLine("jhgfhjfhjfhjfhjfhj")
f.close
print"hfhj"