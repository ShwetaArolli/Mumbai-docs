'''
Created on Mar 20, 2017

@author: shwhegde
'''
print"hi"