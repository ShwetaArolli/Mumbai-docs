'''
Created on Mar 20, 2017

@author: shwhegde
'''
class a:
    a=1
    def r(self,a):
        print(2)
        return a
m=a()
print(m.r(2))

