'''
Created on Mar 20, 2017

@author: shwhegde
'''
# Store input numbers
num1 = input('Enter first number: ')
num2 = input('Enter second number: ')

# Add two numbers
sum = float(num1) + float(num2)

# Display the sum
print('The sum of {1} and {0} is {2}'.format(num1, num2, sum))