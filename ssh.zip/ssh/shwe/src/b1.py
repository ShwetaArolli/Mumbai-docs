'''
Created on Mar 20, 2017

@author: shwhegde
'''
i = 1
for i in range(1, 10):
    if i <= 5 :
        print 'Smaller or equal then 5.\n'; print 'hi'
    else:
        print 'Larger then 5.\n',