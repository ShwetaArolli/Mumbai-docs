'''
Created on Mar 20, 2017

@author: shwhegde
'''
import datetime
ssf=datetime.date.today()
print(ssf.strftime('%d,%b,%Y'))