'''
Created on Mar 20, 2017

@author: shwhegde
'''
a="abc.txt"
b="r"
f=open(a,b)
print(f.read())
f.close()
print"end"