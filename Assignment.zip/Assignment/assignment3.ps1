<#Write PowerShell function ListAllVM() which displays following:
List all VM along with Number vCPU/HAL/OS Version/Service Pack#>

function listAllVms() 
{
	Connect-VIServer -Server '10.207.214.153' -User 'esxiuser' -Password 'cloud@123'
	Get-VM |Where {$_.PowerState -eq �PoweredOn�}|
	Sort Name |Select Name, NumCPU, 
	@{
		N=�OSHAL�;E={(Get-WmiObject -ComputerName $_.Name-Query �SELECT * FROM Win32_PnPEntity where ClassGuid = �{4D36E966		-E325-11CE-BFC1-		08002BE10318}�� |Select Name)}
	},
	@{
		N=�OperatingSystem�;E={(Get-WmiObject -ComputerName $_ -Class Win32_OperatingSystem |Select Caption).Caption}
	},
	@{
		N=�ServicePack�;E={(Get-WmiObject -ComputerName $_ -Class Win32_OperatingSystem |Select CSDVersion).CSDVersion}
	}
}
listAllVms