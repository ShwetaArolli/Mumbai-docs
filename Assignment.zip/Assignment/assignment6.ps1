<#Write PowerShell functions which list how many cpu�s, the amount of memory, average cpu usage for x amount of days and the average memory usage.#>

function getNoOfCpu{
	Get-VM | Where {$_.PowerState -eq 'PoweredOn'}| 
	Select Name, Host, NumCpu, MemoryMB,
 		@{
			N='Cpu.UsageMhz.Average';
			E={
				[Math]::Round((($_ |Get-Stat -Stat cpu.usagemhz.average -Start (Get-Date).AddHours(-24)-IntervalMins 5 -MaxSamples (12) |Measure-Object Value -Average).Average),2)
			}
		}, 
 		@{
			N='Mem.Usage.Average';
			E={
				[Math]::Round((($_ |Get-Stat -Stat mem.usage.average -Start (Get-Date).AddHours(-24)-IntervalMins 5 -MaxSamples (12) |Measure-Object Value -Average).Average),2)
		}
}

}
getNoOfCpu
