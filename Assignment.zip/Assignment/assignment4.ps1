<#Write PowerShell function NumberOfVMStatus() which displays following:
1.Number of power �On� virtual machines connected with Esxi host currently along with their names
2.Number of power �Off� virtual machines connected with Esxi host currently along with their names#>


function NumberOfVMStatus(){  
Connect-VIServer -Server '10.207.214.153' -User 'esxiuser' -Password 'cloud@123'
write-host "#############################################"
write-host "#############################################"

ForEach($on in get-vm){
if($on.powerstate -eq "PoweredOff"){
			$on | where {$on.powerstate -eq 'PoweredOff'} | select name,powerstate | sort powerstate
			write-host "#############################################"
			
					}
Elseif($on.powerstate -eq "PoweredOn"){
			$on | where {$on.powerstate -eq 'PoweredOn'} | select name,powerstate | sort powerstate
			write-host "#############################################"
			
			}


}

	}
NumberOfVMStatus












