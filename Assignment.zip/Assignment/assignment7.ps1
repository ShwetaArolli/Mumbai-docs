<#Write PowerShell function which lists how many VM�s were on each host.#>

function getVMonHost{

	Get-VMHost | Select @{N="Cluster";E={Get-Cluster -VMHost $_}}, Name, @{N="NumVM";E={($_|Get-VM).count}} | Sort 	cluster, count

}
getVMonHost


