echo "enter hostname"
$hostname= read-host hostname
$username= read-host username
$password= read-host password
try
{
connect-Viserver -Server $hostname -User $username -password $password

}
Catch
{
    echo "Catch block"
    $ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName
   
}