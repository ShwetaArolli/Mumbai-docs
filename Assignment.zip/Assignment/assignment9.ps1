<#Write PowerShell function which list the number of vCPU�s assigned to a VM and the type of HAL installed in the O/S#>

function cpuToVm{
	Get-VM |Where {$_.PowerState -eq �PoweredOn�} |Sort Name |Select Name, NumCPU,
        @{
		N=�OSHAL�;
		E={(Get-WmiObject -ComputerName $_.Name-Query �SELECT * FROM Win32_PnPEntity where ClassGuid =			�{4D36E966-E325-11CE-BFC1-08002BE10318}�� |Select Name).Name}

	}
}
cpuToVm
