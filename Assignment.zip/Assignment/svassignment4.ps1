function NumberOfVMStatus(){ 


if(get-vm | where {$_.powerstate -eq 'poweredon'}| select name,powerstate)
{
echo "vms which are powered on"
echo "########################"
}

}
NumberOfVMStatus