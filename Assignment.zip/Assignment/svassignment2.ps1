#Write PowerShell function which accepts hostname, username, password as parameter to connect to Esxi host. If connection is successful then print message �You are connected to host XXX successfully� else throw error message �Your connection was not successful, please verify your username name and password.#


function check{
	echo Hello Welcome!!!
	$myhostname=hostname.exe	
	$myusername=$env:userName
	$mypassword="cloud@123"
	$hostname=Read-Host 'Enter your hostname'
	$username=Read-Host 'Enter your username'
	$password=Read-Host 'Enter your password'	

	while(1){
		
		If(($hostname -eq $myhostname)-And($username -eq $myusername)-And($password -eq $mypassword)){
			break
		}
	Else{
		echo "You have entered the wrong credentials"
		echo "Please verify your hostname,username and password"
		$hostname=Read-Host 'Enter your hostname'
		$username=Read-Host 'Enter your username'
		$password=Read-Host 'Enter your password'
		if(($hostname -eq $myhostname)-And($username -eq $myusername)-And($password -eq $mypassword)){
			break
		}	
	}

	}	
	echo "Welcome you are connected to $myhostname"
}
check