<#Write PowerShell function which lists the number of VMs on each Datastore and export to CSV file#>

#Datastore function called to lists number of vms on each Datastore and export to Csv
function Datastore{

#Get-Datastore lists all Datastore and displays datastore names
	Get-Datastore | Select Name, 
	@{
	#Get-VM command fetches all the vms 
	#.count gives the  count of vms on each datastore
		N="NumVM";E={@($_ | Get-VM).Count}
	} 
	#number of vms and its count is exported to csv file
| Sort Name |Export-Csv "C:\Users\Administrator\Desktop\shweta11.txt"
	}
	#function Datastore
Datastore