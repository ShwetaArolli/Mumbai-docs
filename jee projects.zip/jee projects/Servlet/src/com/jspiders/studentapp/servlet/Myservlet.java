package com.jspiders.studentapp.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;
public class Myservlet extends HttpServlet{
 @Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {
	// TODO Auto-generated method stub
	super.doPost(req, resp);
	Date res=new Date();
	String currdate=res.toString();
	System.out.println("Current date is:"+currdate);
	String htmlresp="<html>"
		+"<body>"+"<h1>"+"Current Date and time is:"+"<font-color='blue'>"+"currdate"+"</font>"+"</h1>"+"</body>"+"</html>";
	resp.setContentType("text/html");
	PrintWriter out=resp.getWriter();
	out.print(htmlresp);
}
	/**
	 * @param args
	 */
	
}
