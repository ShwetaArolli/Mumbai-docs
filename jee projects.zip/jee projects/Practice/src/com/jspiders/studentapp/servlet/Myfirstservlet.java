package com.jspiders.studentapp.servlet;

import java.io.IOException;
import java.util.Date;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/Myfirstservlet")
public class Myfirstservlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
    
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException
	{	
		// TODO Auto-generated method stub
			//super.doPost(req, resp);
			Date dat=new Date();
			String curdate=dat.toString();
			System.out.println("current date is :" +curdate);
			String htmlresp="<html>"+"<body>"+"<h1>"+"Current date :"+"<font color='blue'>"+curdate+"</font>"+"</h1>"+"</body>"+"</html>";
			resp.setContentType("text/html");
			PrintWriter out=resp.getWriter();
			out.print(htmlresp);
		
		
		
		
	}
	
	
}
