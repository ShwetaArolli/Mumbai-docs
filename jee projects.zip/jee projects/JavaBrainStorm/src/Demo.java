
public class Demo {

	public static void main(String[] args) {
		 int arr[]={12,13,14,44}; 
			      minFunction(arr);
			      
			   }

			   /** returns the minimum of two numbers */
			   public static void minFunction(int ...arr) {
				   for(int i:arr){  
					     System.out.println(i);  
					   }  
			   }

}
