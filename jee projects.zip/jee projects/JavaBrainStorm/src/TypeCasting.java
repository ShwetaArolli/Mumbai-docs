
public class TypeCasting {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int i=-130;
		byte j=(byte)i;
		System.out.println(j);
	}

}
