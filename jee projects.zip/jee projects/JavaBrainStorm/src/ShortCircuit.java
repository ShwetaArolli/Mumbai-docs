
public class ShortCircuit {
	public static void main(String[] args) {
		if(2<2&&1/0==1){
			System.out.println("true");
		}else{
			System.out.println("false");
		}
	}
}
