/**
 * 
 */
function sayHi()
{
 document.write("shweta");	
}