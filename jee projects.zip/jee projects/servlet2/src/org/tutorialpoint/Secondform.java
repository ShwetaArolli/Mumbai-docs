package org.tutorialpoint;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/Secondform") 
public class Secondform extends HttpServlet{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {
	// TODO Auto-generated method stub
	resp.setContentType("text/html");
	String message="Simple Checkbox usage ";
	PrintWriter out=resp.getWriter();
	out.println("<html>"+"<head>"+"<title>"+"</title>"+"</head>"+"<body bgcolor='yellow'>"+"<h1 align='center'>"+message+
	"<ul>"+"<li>Maths:</li>\n"+req.getParameter("maths")+"\n"+"<li>Chemistry:</li>\n"+req.getParameter("chemistry")+"\n"+
	"<li> Biology:</li>\n"+req.getParameter("biology")+"\n"+"</body>"+"</html>");
	
	
}
@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(req,resp);
	}

}
