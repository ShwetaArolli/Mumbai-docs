function validate()
{

	var firstname=document.getElementById('firstname');
	var lastname=document.getElementById('lastname');
	var age=document.getElementById('age');
	var number=document.getElementById('number');
	var gender=document.getElementsByClassName('gender');
	var email=document.getElementById('email');
	var regexEmail = /\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/;
	var nameRegex = /^[a-zA-Z\-]+$/;
	var ageRegex =  /^\d+$/;
	var numberRegex = /[0-9]/;
	
	s="";
	if (!(nameRegex.test(firstname.value))) 
		s+="firstname";
	
	if (!(nameRegex.test(lastname.value))) 
		s+=","+"lastname";

	if (!(ageRegex.test(age.value)))
		s+=","+"age";
		
	if (!(numberRegex.test(number.value))) 
		s+=","+"number";

	if (!(regexEmail.test(email.value)))
		s+=","+"email";
	
	alert("Invalid fields: "+s);
}

