function validation()
{
	
	var name=document.getElementById('name');
	var age=document.getElementById('age');
	var gender=document.getElementsByClassName('gender');
	var number=document.getElementById('number');
	var email=document.getElementById('email');
	var regexEmail = /\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/;
	var nameRegex = /^[a-zA-Z\-\s]+$/;

	var ageRegex =  /^\d+$/;
	var numberRegex = /[0-9]/;


	snumber="";
	for(var k=1;k<34;k++)
		{
			if('rgb(102, 102, 255)'==seat[k].style.background)
				{
					snumber+="-"+seat[k].id;	
				}
		}
	
	alert("Selected Seats are : "+snumber);
return true;
	
	s="";
	if (!(nameRegex.test(name.value))) 
		s+="name";

	if (!(ageRegex.test(age.value)))
		s+=","+"age";
		
	if (!(numberRegex.test(number.value))) 
		s+=","+"number";

	if (!(regexEmail.test(email.value)))
		s+=","+"email";
	if(s !=''){
		alert("Invalid fields: "+s);
		return false;
	}
	
		
	
	

}