package servlet;

public class DisplayHeader extends HttpServlet{

}
